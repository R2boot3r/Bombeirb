#include <stdio.h>
#include <stdlib.h>

/*#define STATIC_MAP_WIDTH  12
#define STATIC_MAP_HEIGHT 12*/

char** str_split(char* a_str, const char a_delim);
unsigned char chargement_carte();
