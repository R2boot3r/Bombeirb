#include <SDL/SDL_image.h>
#include <assert.h>

#include <sprite.h>
#include <misc.h>
#include <constant.h>
#include <map.h>
#include <game.h>

struct bomb {
	int range;
  int x,y;
  int timer;
	enum bomb_type bomb_type;
};




struct bomb* bomb_init() {
	struct bomb* bomb;
	bomb = malloc(sizeof(*bomb));
	if (!bomb)
		error("Memory error");
	return bomb;
}

void bomb_set(struct map* map, struct bomb* bomb, int x, int y){
	map_set_compose_type(map,x,y,CELL_BOMB_4);
	bomb->timer = SDL_GetTicks();

}

void bomb_set_position(struct bomb* bomb, int x, int y) {
	assert(bomb);
	bomb->x = x;
	bomb->y = y;
}

void bomb_free(struct bomb* bomb) {
	assert(bomb);
	free(bomb);
}


int bomb_get_x(struct bomb* bomb) {
	assert(bomb != NULL);
	return bomb->x;
}

int bomb_get_y(struct bomb* bomb) {
	assert(bomb != NULL);
	return bomb->y;
}
int bomb_get_range(struct bomb* bomb){
	assert(bomb);
	return bomb->range;
}

int bomb_get_timer(struct bomb* bomb){
	assert(bomb);
	return bomb->timer;
}

void update_bomb_timer(struct bomb* bomb){
	assert(bomb);
	bomb->timer=SDL_GetTicks();
}

/*void bomb_display(struct bomb* bomb) {
	assert(bomb);
	window_display_image(sprite_get_bomb(bomb->bomb_type),
			bomb->x * SIZE_BLOC,bomb->y * SIZE_BLOC);
}*/
