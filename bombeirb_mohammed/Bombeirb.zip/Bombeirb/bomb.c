#include <SDL/SDL_image.h>
#include <assert.h>

#include <player.h>
#include <sprite.h>
#include <window.h>
#include <misc.h>
#include <constant.h>
#include <game.h>
#include <bomb.h>
#include <map.h>

struct bomb {
	int x, y;
	int timer;
	enum bomb_type type;
};

struct bomb* bomb_init(enum bomb_type type, int x, int y) {
	struct bomb* bomb = malloc(sizeof(*bomb));
	
	if (!bomb)
		error("Memory error");

	bomb->type = type;
	bomb->x=x;
	bomb->y=y;
	bomb->timer = SDL_GetTicks();
	return bomb;
}

void bomb_display(struct bomb* bomb) {
	assert(bomb);
	window_display_image(sprite_get_bomb(bomb->type),
				bomb->x * SIZE_BLOC, bomb->y * SIZE_BLOC);
}

void explosion_display (struct player* player,struct map* map, struct bomb* bomb){
	assert(map);
	assert(bomb);
	int H=map_get_height(map);
	int L=map_get_width(map);
	int N=0;
	int E=0;
	int W=0;
	int S=0;
	int range=4;
	int x=bomb->x;
	int y=bomb->y;
	window_display_image(sprite_get_bomb(bomb->type),
				x * SIZE_BLOC, y * SIZE_BLOC);
				
	for(int i=1; i<range; i++){
		if(map_is_inside(map,x+i,y)){
			if(map_get_cell_type(map,x+i,y)==CELL_BOX || map_get_cell_type(map,x+i,y)==CELL_EMPTY){
				if(E!=1 && x+i<=L){
					map_set_cell_type(map,x+i,y,CELL_EMPTY);
					window_display_image(sprite_get_bomb(bomb->type),(x+i) * SIZE_BLOC, y * SIZE_BLOC);
				}
				else{
					E=1;
				}
			}
			else{
				E=1;
			}
				
		}
		if(map_is_inside(map,x,y-i)){

			if(map_get_cell_type(map,x,y-i)==CELL_BOX || map_get_cell_type(map,x,y-i)==CELL_EMPTY){
				if(N!=1	&& y-i>=0){
					map_set_cell_type(map,x,y-i,CELL_EMPTY);
					window_display_image(sprite_get_bomb(bomb->type), x * SIZE_BLOC, (y-i) * SIZE_BLOC);
				}
				else{
					N=1;
				}
			}
			else{
				N=1;
			}
		}
		if(map_is_inside(map,x-i,y)){
			if(map_get_cell_type(map,x-i,y)==CELL_BOX || map_get_cell_type(map,x-i,y)==CELL_EMPTY){
				if(W!=1 && x-i>=0){
					map_set_cell_type(map,x-i,y,CELL_EMPTY);
					window_display_image(sprite_get_bomb(bomb->type),(x-i) * SIZE_BLOC, y * SIZE_BLOC);
				}
				else{
					W=1;
				}
			}
			else{
				W=1;
			}
		}
		if( (y+i) <= (map_get_height(map)-1) ){
			if(map_get_cell_type(map,x,y+i)==CELL_BOX || map_get_cell_type(map,x,y+i)==CELL_EMPTY){
				if(S!=1 && y+i<=H){
					map_set_cell_type(map,x,y+i,CELL_EMPTY);
					window_display_image(sprite_get_bomb(bomb->type),x * SIZE_BLOC, (y+i) * SIZE_BLOC);
				}
				else{
					S=1;
				}
			}
			else{
				S=1;
			}
		}
	}
		
}

void bomb_set_position(struct bomb *bomb, int x, int y) {
	assert(bomb);
	bomb->x = x;
	bomb->y = y;
}

enum bomb_type bomb_get_type(struct bomb* bomb){
	assert(bomb);
	return bomb->type;
}

void bomb_free(struct bomb* bomb) {
	assert(bomb);
	free(bomb);
}

int bomb_update(struct bomb* bomb){
	assert(bomb);
	int ret = 0;
	int now = SDL_GetTicks();
	if(now - bomb->timer > 1000){
		switch(bomb->type){
			case BOMB_4:
				bomb->type = BOMB_3;
				bomb->timer = now;
				break;
			case BOMB_3:
				bomb->type = BOMB_2;
				bomb->timer = now;
				break;
			case BOMB_2:
				bomb->type = BOMB_1;
				bomb->timer = now;
				break;
			case BOMB_1:
				bomb->type = BOMB_0;
				bomb->timer = now;
				break;
			case BOMB_0:
				ret = 1;
				break;
			default:
				break;
		}
	}
	return ret;
}

