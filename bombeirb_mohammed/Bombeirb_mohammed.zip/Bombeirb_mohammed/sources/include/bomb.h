/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère & Mohamed EL BOUDALI
 ******************************************************************************/
#ifndef BOMB_H_
#define BOMB_H_

#include <map.h>
#include <constant.h>
#include <game.h>

struct bomb;
//struct Liste_bomb;

// Creates a new player with a given number of available bombs
struct bomb* bomb_init();
//struct List_bomb* listbomb_init();
void bomb_free(struct bomb* bomb);
//void new_bomb(struct Liste_bomb * Liste_bomb; int newbomb);
void bomb_set_bomb(struct bomb* bomb, int x, int y);


// Set the position of the player
void bomb_set_position(struct bomb *bomb, int x, int y);

// Returns the current position of the player
int bomb_get_x(struct bomb* bomb);
int bomb_get_y(struct bomb* bomb);
int bomb_get_timer(struct bomb* bomb);
void update_bomb_timer(struct bomb* bomb);
void bomb_set(struct map* map, struct bomb* bomb,int x, int y);
// Move the player according to the current direction
// Display the player on the screen
//void bomb_display(struct bomb* bomb);

#endif /* BOMB_H_ */
