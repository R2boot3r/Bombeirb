/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2008 by Laurent Réveillère
 ******************************************************************************/
#include <assert.h>
#include <time.h>

#include <game.h>
#include <misc.h>
#include <window.h>
#include <sprite.h>
#include <monster.h>
#include <bomb.h>

struct game {
	struct map** maps;       // the game's map
	short levels;        // nb maps of the game
	short level;
	struct player* player;
	struct monster** monsters;
	short nb_monster;
};

struct game*
game_new(int level) {
	sprite_load(); // load sprites into process memory

	struct game* game = malloc(sizeof(*game));
	game->maps = malloc(sizeof(struct game));
	game->monsters = malloc(sizeof(struct game));
	game->maps[0] = map_get_static_1();
	game->maps[1] = map_get_static_2();
	game->levels = 10;
	game->nb_monster = 4;
	game->level = 0;
	game->player = player_init(3,3);
	game->monsters[0] = monster_init();
	game->monsters[1] = monster_init();
	//game->monsters[0] = monster_init();
	// Set default location of the player
	//game->bombs=NULL;
	player_set_position(game->player, 1, 0);
	monster_set_position(game->monsters[0], 8,6);
	monster_set_position(game->monsters[1], 6,6);
	//monster_set_position(game->monsters[2], 5,6);
	//monster_set_position(game->monsters[3], 4,6);
	//monster_set_position(game->monsters[4], 3,6);

	return game;
}

void monsters_move(struct game* game){
	struct map* map = game_get_current_map(game);
	for (int i = 0; i<2; i++){
		monster_move(game->monsters[i],map);
	}
}


void game_free(struct game* game) {
	assert(game);
	monster_free(game->monsters[0]);
	monster_free(game->monsters[1]);
	player_free(game->player);
	for (int i = 0; i < game->levels; i++)
		map_free(game->maps[i]);
}


struct map* game_get_current_map(struct game* game) {
	assert(game);
	return game->maps[game->level];
}


struct player* game_get_player(struct game* game) {
	assert(game);
	return game->player;
}

void game_bomb_explosion(struct game* game){
	int S,E,N,W;
	struct map* map= game_get_current_map(game);
	int width=map_get_width(map);
	int height=map_get_height(map);
	int t=SDL_GetTicks();
	for(int i = 0; i<width; i++){
		for(int j=0; j<height; j++){

			if(map_get_cell_type(map,i,j) == CELL_BOMB){
				if(bomb_get_bomb_type(map,i,j)== BOMB4){
					map_set_compose_type(map,i,j,CELL_BOMB_3);
				}
				else if(bomb_get_bomb_type(map,i,j)== BOMB3){
					map_set_compose_type(map,i,j,CELL_BOMB_2);
				}
				else if(bomb_get_bomb_type(map,i,j)== BOMB2){
					map_set_compose_type(map,i,j,CELL_BOMB_1);
				}
				else if(bomb_get_bomb_type(map,i,j)== BOMB1){
					map_set_cell_type(map,i,j,CELL_EXPLOSION);
					W=bomb_explosion_case_cell(game, i-1,j);
						E=bomb_explosion_case_cell(game, i+1,j);
					S=bomb_explosion_case_cell(game, i, j+1);
						N=bomb_explosion_case_cell(game, i, j-1);
				}
			}
			else if(map_get_cell_type(map,i,j)==CELL_EXPLOSION){
				printf("CELL_EXPLOSION se trouve dans %d suivant x et %d suivant y\n", i,j );
				map_set_cell_type(map,i,j,CELL_EMPTY);
				}
			}
		}
	}

int bomb_explosion_case_cell(struct game * game, int i, int j){
	int Bn;
	struct map* map= game_get_current_map(game);
	printf("la valeur de i est %d\n", i);
	printf("la valeur de j est %d\n", j);
	int c = map_get_cell_type(map, i,j);
	printf("=====%d\n", c);
	switch (map_get_cell_type(map, i, j)) {
		case CELL_SCENERY:
			bomb_explosion_case_cell_scenery(game, i,j);
			return 0;
		break;
		case CELL_BOX:
			map_set_cell_type(map, i,j,CELL_EXPLOSION);
			return 0;
		break;
		case CELL_BONUS:
			//Bn=bomb_explosion_case_cell_bonus(game);
		break;

		case CELL_KEY:
		break;

		case CELL_DOOR:
		break;

		case CELL_EMPTY	:
			//printf()
			map_set_cell_type(map, i,j,CELL_EXPLOSION);

			return 0;
		break;
		default:
		break;

	}
}



void bomb_explosion_case_cell_scenery(struct game* game, int i, int j){
	struct map* map= game_get_current_map(game);
	switch (map_get_cell_scenery(map,i,j)) {
		case SCENERY_TREE:
			//map_set_compose_type(map,i,j,CELL_EXPLOSION);
			break;
		case SCENERY_STONE:
			break;
		case SCENERY_PRINCESS:
			break;
	}
}


void game_banner_display(struct game* game) {
	assert(game);

	struct map* map = game_get_current_map(game);

	int y = (map_get_height(map)) * SIZE_BLOC;
	for (int i = 0; i < map_get_width(map); i++)
		window_display_image(sprite_get_banner_line(), i * SIZE_BLOC, y);

	int white_bloc = ((map_get_width(map) * SIZE_BLOC) - 6 * SIZE_BLOC) / 4;
	int x = white_bloc;
	y = (map_get_height(map) * SIZE_BLOC) + LINE_HEIGHT;
	window_display_image(sprite_get_banner_life(), x, y);

	x = white_bloc + SIZE_BLOC;
	window_display_image(
		sprite_get_number(player_get_nb_hurt(game_get_player(game))), x, y);

	x = 2 * white_bloc + 2 * SIZE_BLOC;
	window_display_image(sprite_get_banner_bomb(), x, y);

	x = 2 * white_bloc + 3 * SIZE_BLOC;
	window_display_image(
			sprite_get_number(player_get_nb_bomb(game_get_player(game))), x, y);

	x = 3 * white_bloc + 4 * SIZE_BLOC;
	window_display_image(sprite_get_banner_range(), x, y);

	x = 3 * white_bloc + 5 * SIZE_BLOC;
	window_display_image(sprite_get_number(3), x, y);
}




void game_player_monster_collision(struct game* game){
	int i = player_get_x(game->player);
	int j = player_get_y(game->player);
	for (int k; k<2 ; k++){
		if (i == monster_get_x(game->monsters[k]) && monster_get_y(game->monsters[k]) == j){
			player_dec_nb_hurt(game->player);
		}
	}
}




void game_display(struct game* game) {
	assert(game);
	window_clear();
	game_banner_display(game);
	map_display(game_get_current_map(game));
	player_display(game->player);
	monster_display(game->monsters[0]);
	monster_display(game->monsters[1]);
	window_refresh();
}

static short input_keyboard(struct game* game) {
	SDL_Event event;
	struct player* player = game_get_player(game);
	struct map* map = game_get_current_map(game);
	int i = player_get_x(player);
	int j = player_get_y(player);
	while (SDL_PollEvent(&event)) {

		switch (event.type){
		case SDL_QUIT:
			return 1;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
			case SDLK_ESCAPE:
				return 1;
			case SDLK_UP:
				player_set_current_way(player, NORTH);
				player_move(player, map);
				break;
			case SDLK_DOWN:
				player_set_current_way(player, SOUTH);
				player_move(player, map);
				break;
			case SDLK_RIGHT:
				player_set_current_way(player, EAST);
				player_move(player, map);
				break;
			case SDLK_LEFT:
				player_set_current_way(player, WEST);
				player_move(player, map);
				break;
			case SDLK_SPACE:
				bomb_init(map,i,j);
				break;
			default:
				break;
			}
		break;
		}
	}
	return 0;
}



int game_update(struct game* game) {
	if (input_keyboard(game)){
		return 1; // exit game
	}
	return 0;
}
